// /** @type {import('next').NextConfig} */
// const nextConfig = {}

// module.exports = nextConfig
require('dotenv').config();

module.exports = {
  reactStrictMode: true,
  // other Next.js config options
};
