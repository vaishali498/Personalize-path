# AI Path Generator
[ai-path-gen.vercel.app]()

This is an AI-powered learning path generator which suggests you the best learning path for you to learn new programming skills based on your current knowledge. It uses GPT-3.5 Turbo to generate the learning paths.

This is my first actual next.js and OpenAI project. I learned a lot while building. I hope you like it. There are a few corners short, but I will try to fix them.

